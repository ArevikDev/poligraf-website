<?php

class Tribe__Tickets_Plus__Meta__Field__Number extends Tribe__Tickets_Plus__Meta__Field__Abstract_Field {
	public $type = 'number';

	public function save_value( $attendee_id, $field, $value ) {
	}
}
