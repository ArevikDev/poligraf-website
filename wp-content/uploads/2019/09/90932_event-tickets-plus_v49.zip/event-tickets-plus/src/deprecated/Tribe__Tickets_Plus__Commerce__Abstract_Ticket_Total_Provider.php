<?php
_deprecated_file( __FILE__, '4.6', 'Tribe__Tickets_Plus__Commerce__Abstract_Ticket_Total_Provider' );

/**
 * @deprecated 4.6
 */
class Tribe__Tickets_Plus__Commerce__Abstract_Ticket_Total_Provider {
	public function __get( $unused ) {}
	public function __set( $unused_a, $unused_b ) {}
	public function __call( $unused_a, $unused_b ) {}
}