<?php
	_deprecated_file( __FILE__, '3.10', 'Tribe__Tickets_Plus__Commerce__EDD__Main' );


	class TribeEDDTickets extends Tribe__Tickets_Plus__Commerce__EDD__Main {

	}
